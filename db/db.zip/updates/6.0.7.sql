ALTER TABLE `products` ADD `exclusive_to_website` TINYINT NOT NULL DEFAULT '0' AFTER `archive`;
