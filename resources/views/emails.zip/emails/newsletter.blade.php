

    <div style="    font-size: 12px;
    display: inline-block;
    direction: rtl">
    <p>{{$array['content']}}</p>

    </div>
