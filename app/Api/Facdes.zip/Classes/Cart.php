<?php

namespace App\Api\Classes;

class Cart
{

    public function store()
    {
    }
}
